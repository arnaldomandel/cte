 
NAME:

      silaba2008.pl

DESCRIPTION 

	Program used to encode the linguistic data for the linguistic application appearing in Annals of Applied Statistics:

	Context tree selection and linguistic rhythm retrieval from written texts.
 
	Can be downloaded from ArXiv: 0902.3619v3, 2011.

 AUTHOR 

	Miguel Galves (miguel.galves@ic.unicamp.br)


 REQUIREMENTS 

   - Perl must be installed on the computer. 


 USAGE

     perl silaba2008.pl datafile

 ARGUMENTS
    
   datafile    : ASCII file with the text.

  