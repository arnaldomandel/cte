
The data we analyze is a encoded corpus of newspaper articles
extracted from Folha de Sao Paulo and Publico, daily newspapers
from Brazil and Portugal respectively. The sample consists of 80
articles randomly selected from the 1994 and 1995 editions. 
These editions are available through the project AC/DC  at 
http://www.linguateca.pt/CETENFolha/ and  http://www.linguateca.pt/CETEMPublico/ 
respectively. 

The newspapers articles of the sample were selected in the following
way. We first randomly selected 20 editions for each newspaper for
each year.  Inside each edition we discarded all the texts with less
than 1000 words as well as some type of articles (interviews,
synopsis, transcriptions of laws and collected works) which are
unsuitable for our purposes. From the remaining articles we randomly
selected one article for each previously selected edition.

Before encoding each one of the selected texts, they were submitted to
a linguistically oriented cleaning procedure. Hyphenated compound
words were rewritten as two separate words, except when one of the
components is unstressed. Suspension points, question marks and
exclamation points were replaced by periods. Dates and special symbols
like were spelled out as words. All parentheses were removed.

